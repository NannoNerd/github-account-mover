-- Add duration field to videos table
ALTER TABLE public.videos ADD COLUMN duration TEXT;